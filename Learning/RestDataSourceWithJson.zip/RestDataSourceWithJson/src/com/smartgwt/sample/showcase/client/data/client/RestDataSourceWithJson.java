package com.smartgwt.sample.showcase.client.data.client;

import com.google.gwt.core.client.EntryPoint;
import com.smartgwt.client.core.KeyIdentifier;
import com.smartgwt.client.data.RestDataSource;
import com.smartgwt.client.data.fields.DataSourceBooleanField;
import com.smartgwt.client.data.fields.DataSourceDateField;
import com.smartgwt.client.data.fields.DataSourceFloatField;
import com.smartgwt.client.data.fields.DataSourceIntegerField;
import com.smartgwt.client.data.fields.DataSourceLinkField;
import com.smartgwt.client.data.fields.DataSourceTextField;
import com.smartgwt.client.types.DSDataFormat;
import com.smartgwt.client.util.KeyCallback;
import com.smartgwt.client.util.Page;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;

public class RestDataSourceWithJson implements EntryPoint {

    private ListGrid listGrid;

    private IButton addButton;

    private IButton updateButton;

    private IButton removeButton;

    public void onModuleLoad() {
        initDebugKey();
        initView();
    }

    private void initDebugKey() {
        KeyIdentifier debugKey = new KeyIdentifier();
        debugKey.setCtrlKey(true);
        debugKey.setKeyName("D");
        Page.registerKey(debugKey, new KeyCallback() {
            public void execute(String keyName) {
                SC.showConsole();
            }
        });
    }

    private void initView() {
        VLayout main = createMain();
        main.draw();
    }

    private VLayout createMain() {
        VLayout result = new VLayout(15);
        result.setAutoHeight();
        result.setWidth("100%");
        result.setMargin(20);
        result.setMembersMargin(10);

        listGrid = createCountryListGrid();
        result.addMember(listGrid);

        result.addMember(createButtons());

        return result;
    }

    private HLayout createButtons() {
        HLayout result = new HLayout();
        result.setMembersMargin(10);

        addButton = createAddButton();
        result.addMember(addButton);

        updateButton = createUpdateButton();
        result.addMember(updateButton);

        removeButton = createRemoveButton();
        result.addMember(removeButton);

        return result;
    }

    private IButton createRemoveButton() {
        IButton result = new IButton("Remove Country (UK)");
        result.setWidth(150);

        result.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                onRemoveData();
            }
        });

        return result;
    }

    private void onRemoveData() {
        ListGridRecord record = new ListGridRecord();
        record.setAttribute("countryCode", "UK");

        listGrid.removeData(record);
        removeButton.disable();
    }

    private IButton createUpdateButton() {
        IButton result = new IButton("Update Country (US)");
        result.setWidth(150);

        result.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                onUpdateData();
            }
        });

        return result;
    }

    private void onUpdateData() {
        ListGridRecord record = new ListGridRecord();
        record.setAttribute("countryCode", "US");
        record.setAttribute("countryName", "Edited Value");
        record.setAttribute("capital", "Edited Value");
        record.setAttribute("continent", "Edited Value");

        listGrid.updateData(record);
        updateButton.disable();
    }

    private IButton createAddButton() {
        IButton result = new IButton("Add new Country");
        result.setWidth(150);

        result.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                ListGridRecord record = new ListGridRecord();
                record.setAttribute("countryCode", "A1");
                record.setAttribute("countryName", "New Value");
                record.setAttribute("capital", "New Value");
                record.setAttribute("continent", "New Value");
                
                listGrid.addData(record);
                addButton.disable();
            }
        });

        return result;
    }

    private void onAddData() {
        ListGridRecord record = new ListGridRecord();
        record.setAttribute("countryCode", "A1");
        record.setAttribute("countryName", "New Value");
        record.setAttribute("capital", "New Value");
        record.setAttribute("continent", "New Value");

        listGrid.addData(record);
        addButton.disable();
    }

    private ListGrid createCountryListGrid() {
        ListGrid result = new ListGrid();
        result.setWidth("100%");
        result.setHeight(400);
        result.setAutoFetchData(true);

        result.setDataSource(createCountryRestDataSource());

        return result;
    }

    private RestDataSource createCountryRestDataSource() {
        RestDataSource result = new RestDataSource();
        result.setDataFormat(DSDataFormat.JSON);

        DataSourceTextField continentField = new DataSourceTextField("continent", "Continent");
        DataSourceTextField countryNameField = new DataSourceTextField("countryName", "Country");
        DataSourceTextField countryCodeField = createCountryCodeField();
        DataSourceIntegerField areaField = new DataSourceIntegerField("area", "Area");
        DataSourceIntegerField populationField = new DataSourceIntegerField("population", "Population");
        DataSourceFloatField gdpField = new DataSourceFloatField("gdp", "Gdp");
        DataSourceDateField independenceField = new DataSourceDateField("independence", "Independence");
        DataSourceTextField governmentField = new DataSourceTextField("government", "Government");
        DataSourceIntegerField governmentDescField = new DataSourceIntegerField("government_desc", "Government desc");
        DataSourceTextField capitalField = new DataSourceTextField("capital", "Capital");
        DataSourceBooleanField memberG8Field = new DataSourceBooleanField("member_g8", "Member g8");
        DataSourceLinkField articleField = new DataSourceLinkField("article", "Article");

        result.setFields(continentField, countryNameField, countryCodeField, areaField, populationField, gdpField, independenceField,
                governmentField, governmentDescField, capitalField, memberG8Field, articleField);

        result.setFetchDataURL("data/dataIntegration/json/responses/country_fetch_rest.js");
        result.setAddDataURL("data/dataIntegration/json/responses/country_add_rest.js");
        result.setUpdateDataURL("data/dataIntegration/json/responses/country_update_rest.js");
        result.setRemoveDataURL("data/dataIntegration/json/responses/country_remove_rest.js");

        return result;
    }

    private DataSourceTextField createCountryCodeField() {
        DataSourceTextField result = new DataSourceTextField("countryCode", "Code");
        result.setPrimaryKey(true);
        result.setCanEdit(false);
        result.setHidden(true);
        return result;
    }
}