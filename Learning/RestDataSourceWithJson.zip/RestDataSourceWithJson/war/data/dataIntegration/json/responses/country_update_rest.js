{
    response: {
        status: 0,
        data: [
            {
                countryCode: "US",
                continent: "Edited Saved Value",
                countryName: "Edited Saved Value",
                capital: "Edited Saved Value",
                area: 9631420,
                population: 298444215,
                gdp: 12360000,
                independence: new Date(1776, 07, 04),
                government: "federal republic",
                government_desc: 2,
                member_g8: true,
                article: "http://en.wikipedia.org/wiki/United_states"
            }
        ]
    }
}