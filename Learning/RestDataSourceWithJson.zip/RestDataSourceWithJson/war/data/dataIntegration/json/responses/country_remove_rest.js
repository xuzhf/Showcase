{
    response: {
        status: 0,
        data: [
        	{
            	countryCode: "UK"             
            }
        ]
    }
}